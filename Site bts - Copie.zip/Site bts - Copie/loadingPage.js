window.addEventListener('load', function() {
    const loadingScreen = document.getElementById('loading-screen');
    loadingScreen.style.display = 'none';  // Cache l'écran de chargement une fois que la page est entièrement chargée
});
